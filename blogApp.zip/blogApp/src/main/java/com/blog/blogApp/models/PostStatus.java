package com.blog.blogApp.models;

public enum PostStatus {
    DRAFT,
    PUBLISHED
}
